copy /B pro0.d2 + scpu_pgb.d3 + scpu_pgc.d4 + scpu_pgd.d5 + scpu_pge.d6 + scpu_pgf.d7 tron_cpu.bin
make_vhdl_prom tron_cpu.bin tron_cpu.vhd

copy /B ssi_0a.a7 + ssi_0b.a8 + ssi_0c.a9 tron_sound_cpu.bin
make_vhdl_prom tron_sound_cpu.bin tron_sound_cpu.vhd

make_vhdl_prom scpu_bgg.g3 tron_bg_bits_1.vhd
make_vhdl_prom scpu_bgh.g4 tron_bg_bits_2.vhd 

rem make_vhdl_prom vga.e1  tron_sp_bits_1.vhd
rem make_vhdl_prom vgb.dc1 tron_sp_bits_2.vhd
rem make_vhdl_prom vgc.cb1 tron_sp_bits_3.vhd
rem make_vhdl_prom vga.a1  tron_sp_bits_4.vhd

copy /B vga.e1 + vgb.dc1 + vgc.cb1 + vga.a1 tron_sp_bits.bin

make_vhdl_prom tron_sp_bits.bin  tron_sp_bits.vhd

make_vhdl_prom midssio_82s123.12d midssio_82s123.vhd


rem midssio_82s123.12d CRC e1281ee9

rem pro0.d2     CRC 0de0471a
rem scpu_pgb.d3 CRC 8ddf8717
rem scpu_pgc.d4 CRC 4241e3a0
rem scpu_pgd.d5 CRC 035d2fe7
rem scpu_pge.d6 CRC 24c185d8
rem scpu_pgf.d7 CRC 38c4bbaf

rem ssi_0a.a7   CRC 765e6eba
rem ssi_0b.a8   CRC 1b90ccdd
rem ssi_0c.a9   CRC 3a4bc629

rem scpu_bgg.g3 CRC 1a9ed2f5
rem scpu_bgh.g4 CRC 3220f974

rem vga.e1      CRC bc036d1d
rem vgb.dc1     CRC 58ee14d3
rem vgc.cb1     CRC 3329f9d4
rem vga.a1      CRC 9743f873