---------------------------------------------------------------------------------
-- DE10_lite Top level Phoenix by Dar (darfpga@aol.fr) (30/01/2025)
-- http://darfpga.blogspot.fr
---------------------------------------------------------------------------------
-- Educational use only
-- Do not redistribute synthetized file with roms
-- Do not redistribute roms whatever the form
-- Use at your own risk
---------------------------------------------------------------------------------
-- Use Phoenix_de10_lite.sdc to compile (Timequest constraints)
-- /!\
-- Don't forget to set device configuration mode with memory initialization 
--  (Assignments/Device/Pin options/Configuration mode)
---------------------------------------------------------------------------------
--
-- Main features :
--  PS2 keyboard input @gpio pins 35/34 (beware voltage translation/protection) 
--  Audio pwm output   @gpio pins 1/3 (beware voltage translation/protection) 
--
-- Uses 1 pll for 11MHz generation from 50MHz
--
-- Board key :
--   0 : reset game
--
--- Board switch :
--   0 - 7 : dip switch
--             0-1 : lives 3-6
--             3-2 : bonus life 30K-60K
--               4 : coin 1-2
--             6-5 : unkonwn
--               7 : upright-cocktail  
--   8 -10 : sound_select
--             0XX : all mixed (normal)
--             100 : sound1 only 
--             101 : sound2 only
--             110 : sound3 only
--             111 : melody only 
--
-- Other details : see phoenix.vhd
-- For USB inputs and SGT5000 audio output see my other project: xevious_de10_lite
---------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

library work;

entity phoenix_de10_lite is
port(
 max10_clk1_50  : in std_logic;
-- max10_clk2_50  : in std_logic;
-- adc_clk_10     : in std_logic;
 ledr           : out std_logic_vector(9 downto 0);
 key            : in std_logic_vector(1 downto 0);
 sw             : in std_logic_vector(9 downto 0);

-- dram_ba    : out std_logic_vector(1 downto 0);
-- dram_ldqm  : out std_logic;
-- dram_udqm  : out std_logic;
-- dram_ras_n : out std_logic;
-- dram_cas_n : out std_logic;
-- dram_cke   : out std_logic;
-- dram_clk   : out std_logic;
-- dram_we_n  : out std_logic;
-- dram_cs_n  : out std_logic;
-- dram_dq    : inout std_logic_vector(15 downto 0);
-- dram_addr  : out std_logic_vector(12 downto 0);

-- hex0 : out std_logic_vector(7 downto 0);
-- hex1 : out std_logic_vector(7 downto 0);
-- hex2 : out std_logic_vector(7 downto 0);
-- hex3 : out std_logic_vector(7 downto 0);
-- hex4 : out std_logic_vector(7 downto 0);
-- hex5 : out std_logic_vector(7 downto 0);

 vga_r     : out std_logic_vector(3 downto 0);
 vga_g     : out std_logic_vector(3 downto 0);
 vga_b     : out std_logic_vector(3 downto 0);
 vga_hs    : out std_logic;
 vga_vs    : out std_logic;
 
-- gsensor_cs_n : out   std_logic;
-- gsensor_int  : in    std_logic_vector(2 downto 0); 
-- gsensor_sdi  : inout std_logic;
-- gsensor_sdo  : inout std_logic;
-- gsensor_sclk : out   std_logic;

-- arduino_io      : inout std_logic_vector(15 downto 0); 
-- arduino_reset_n : inout std_logic;
 
 gpio          : inout std_logic_vector(35 downto 0)
);
end phoenix_de10_lite;

architecture struct of phoenix_de10_lite is


 signal clk11  : std_logic;
 signal pll_locked :std_logic;
 
 signal r         : std_logic_vector(1 downto 0);
 signal g         : std_logic_vector(1 downto 0);
 signal b         : std_logic_vector(1 downto 0);
 signal video_clk : std_logic;
 signal csync     : std_logic;
 
 signal reset        : std_logic;
 
 alias  dip_switch   : std_logic_vector(7 downto 0) is sw(7 downto 0);
 
 signal blankn    : std_logic;
 
 signal audio           : std_logic_vector(11 downto 0);
 signal pwm_accumulator : std_logic_vector(12 downto 0);

 alias reset_n         : std_logic is key(0);
 alias ps2_clk         : std_logic is gpio(35); --gpio(0);
 alias ps2_dat         : std_logic is gpio(34); --gpio(1);
 alias pwm_audio_out_l : std_logic is gpio(1);  --gpio(2);
 alias pwm_audio_out_r : std_logic is gpio(3);  --gpio(3);
   
signal dbg_cpu_addr : std_logic_vector(15 downto 0);

begin

reset <= not reset_n;
blankn <= '1';

-- tv15Khz_mode <= sw();

--arduino_io not used pins
--arduino_io(7) <= '1'; -- to usb host shield max3421e RESET
--arduino_io(8) <= 'Z'; -- from usb host shield max3421e GPX
--arduino_io(9) <= 'Z'; -- from usb host shield max3421e INT
--arduino_io(13) <= 'Z'; -- not used
--arduino_io(14) <= 'Z'; -- not used

-- Clock 11MHz for Phoenix core
clocks : entity work.max10_pll_11M
port map(
 inclk0 => max10_clk1_50,
 c0 => clk11,
 locked => open --pll_locked
);


phoenix : entity work.phoenix
port map(
 clock_50     => max10_clk1_50,
 clock_11     => clk11,
-- reset        => writing_ram,
 reset        => reset,
-- tv15Khz_mode => tv15Khz_mode,
 dip_switch   => dip_switch,
 ps2_clk      => ps2_clk,
 ps2_dat      => ps2_dat,
 video_r      => r,
 video_g      => g,
 video_b      => b,
 video_clk    => video_clk,
 video_csync  => csync,
-- video_blank  => blank,
-- video_hs     => hsync,
-- video_vs     => vsync,
  audio_select => "000", --audio_select,
 audio        => audio
-- adr_cpu_out  => adr_cpu,
-- do_prog      => sram_dq(7 downto 0)
);

-- adapt video to 4bits/color only
vga_r <= r&"00" when blankn = '1' else "0000";
vga_g <= g&"00" when blankn = '1' else "0000";
vga_b <= b&"00" when blankn = '1' else "0000";

-- synchro composite/ synchro horizontale
vga_hs <= csync;
-- vga_hs <= csync when tv15Khz_mode = '1' else hsync;
-- commutation rapide / synchro verticale
vga_vs <= '1';
-- vga_vs <= '1'   when tv15Khz_mode = '1' else vsync;


-- debug display

ledr(8 downto 0) <= "101010101";
--
--h0 : entity work.decodeur_7_seg port map(dbg_cpu_addr( 3 downto  0),hex0);
--h1 : entity work.decodeur_7_seg port map(dbg_cpu_addr( 7 downto  4),hex1);
--h2 : entity work.decodeur_7_seg port map(dbg_cpu_addr(11 downto  8),hex2);
--h3 : entity work.decodeur_7_seg port map(dbg_cpu_addr(15 downto 12),hex3);
--h4 : entity work.decodeur_7_seg port map(,hex4);
--h5 : entity work.decodeur_7_seg port map(,hex5);

-- pwm sound output

process(clk11)  -- use same clock as pooyan_sound_board
begin
  if rising_edge(clk11) then
    pwm_accumulator  <=  std_logic_vector(unsigned('0' & pwm_accumulator(11 downto 0)) + unsigned(audio & '0'));
  end if;
end process;

pwm_audio_out_l <= pwm_accumulator(12);
pwm_audio_out_r <= pwm_accumulator(12); 

end struct;
